import { useEffect, useState } from 'react';
import {
	X,
	Circle,
	Play,
	Pause,
	Maximize2,
	Minimize2,
	LayoutGrid,
	Zap,
	MousePointer,
	AudioWaveform,
	Image as ImageIcon,
	SlidersHorizontal,
	Move
} from 'lucide-react';
import { useShallow } from 'zustand/react/shallow';
import { useWallpaperStore } from '@/store/wallpaperStore';
import { useT } from '@/lib/i18n';
import EditorOverlay from './EditorOverlay';
import {
	EDITOR_THEME_CLASSES,
	getEditorRadiusVars,
	getScopedEditorThemeColorVars
} from './editorTheme';
import { useWindowPresentationControls } from '@/hooks/useWindowPresentationControls';
import { useAudioContext } from '@/context/useAudioContext';
import { useBackgroundPalette } from '@/hooks/useBackgroundPalette';
import {
	AudioTab,
	BgTab,
	ControlTabSuspense,
	DiagnosticsTab,
	ExportTab,
	FiltersTab,
	LayersTab,
	LyricsTab,
	LogoTab,
	MotionTab,
	OverlaysTab,
	PerfTab,
	EditorTab,
	SceneTab,
	SpectrumTab,
	TrackTitleTab
} from './controlTabsLazy';
import VisualWorkloadBanner from './VisualWorkloadBanner';
import {
	PANEL_ANCHOR_OVERLAY_CLASS,
	PANEL_ANCHOR_WRAPPER_CLASS
} from './controlPanelAnchorStyles';
import {
	ADVANCED_RESET_KEYS,
	LEGACY_TAB_KEYS,
	MAIN_TAB_RESET_KEYS,
	resolveCanvasInteractionTab,
	type AdvancedSubTab,
	type MainTabId
} from './controlPanelResetKeys';
import type { ActiveTool } from '@/types/wallpaper';
import IconButton from './ui/IconButton';
import { ICON_SIZE } from './ui/designTokens';

interface ControlPanelProps {
	open: boolean;
	maximized: boolean;
	forceMaximized?: boolean;
	onOpenChange: (value: boolean) => void;
	onMaximizedChange: (value: boolean) => void;
	onForceClose?: () => void;
}

export default function ControlPanel({
	open,
	maximized,
	forceMaximized = false,
	onOpenChange,
	onMaximizedChange,
	onForceClose
}: ControlPanelProps) {
	const [tab, setTab] = useState<MainTabId>('scene');
	const [advancedSub, setAdvancedSub] = useState<AdvancedSubTab>('track');
	const setControlPanelActiveTab = useWallpaperStore(
		s => s.setControlPanelActiveTab
	);
	useEffect(() => {
		setControlPanelActiveTab(resolveCanvasInteractionTab(tab, advancedSub));
		return () => setControlPanelActiveTab(null);
	}, [tab, advancedSub, setControlPanelActiveTab]);
	const t = useT();
	const {
		language,
		selectedOverlayId,
		overlays,
		controlPanelAnchor,
		editorTheme,
		editorThemeColorSource,
		editorCornerRadius,
		editorControlCornerRadius,
		editorUiScale,
		editorManualAccentColor,
		editorManualSecondaryColor,
		editorManualBackdropColor,
		editorManualTextPrimaryColor,
		editorManualTextSecondaryColor,
		editorManualBackdropOpacity,
		editorManualBlurPx,
		editorManualSurfaceOpacity,
		editorManualItemOpacity,
		logoUrl,
		audioPaused,
		motionPaused,
		uiMode,
		enableDragMode,
		activeTool
	} = useWallpaperStore(
		useShallow(s => ({
			language: s.language,
			selectedOverlayId: s.selectedOverlayId,
			overlays: s.overlays,
			controlPanelAnchor: s.controlPanelAnchor,
			editorTheme: s.editorTheme,
			editorThemeColorSource: s.editorThemeColorSource,
			editorUiScale: s.editorUiScale,
			editorCornerRadius: s.editorCornerRadius,
			editorControlCornerRadius: s.editorControlCornerRadius,
			editorManualAccentColor: s.editorManualAccentColor,
			editorManualSecondaryColor: s.editorManualSecondaryColor,
			editorManualBackdropColor: s.editorManualBackdropColor,
			editorManualTextPrimaryColor: s.editorManualTextPrimaryColor,
			editorManualTextSecondaryColor: s.editorManualTextSecondaryColor,
			editorManualBackdropOpacity: s.editorManualBackdropOpacity,
			editorManualBlurPx: s.editorManualBlurPx,
			editorManualSurfaceOpacity: s.editorManualSurfaceOpacity,
			editorManualItemOpacity: s.editorManualItemOpacity,
			logoUrl: s.logoUrl,
			audioPaused: s.audioPaused,
			motionPaused: s.motionPaused,
			uiMode: s.uiMode,
			enableDragMode: s.enableDragMode,
			activeTool: s.activeTool
		}))
	);
	const resetSection = useWallpaperStore(s => s.resetSection);
	const resetSceneSlotBindings = useWallpaperStore(
		s => s.resetSceneSlotBindings
	);
	const setLanguage = useWallpaperStore(s => s.setLanguage);
	const updateOverlay = useWallpaperStore(s => s.updateOverlay);
	const setSelectedOverlayId = useWallpaperStore(s => s.setSelectedOverlayId);
	const setAudioPaused = useWallpaperStore(s => s.setAudioPaused);
	const setMotionPaused = useWallpaperStore(s => s.setMotionPaused);
	const setUIMode = useWallpaperStore(s => s.setUIMode);
	const setEnableDragMode = useWallpaperStore(s => s.setEnableDragMode);
	const setActiveTool = useWallpaperStore(s => s.setActiveTool);
	const { isFullscreen, fullscreenSupported, toggleFullscreen } =
		useWindowPresentationControls();
	const {
		captureMode,
		isPaused,
		pauseFileForSystem,
		resumeFileFromSystem
	} = useAudioContext();
	const theme = EDITOR_THEME_CLASSES[editorTheme];
	const backgroundPalette = useBackgroundPalette();
	const themeVars = getScopedEditorThemeColorVars(
		editorThemeColorSource,
		backgroundPalette,
		editorTheme,
		{
			accent: editorManualAccentColor,
			secondary: editorManualSecondaryColor,
			backdrop: editorManualBackdropColor,
			textPrimary: editorManualTextPrimaryColor,
			textSecondary: editorManualTextSecondaryColor
		},
		{
			backdropOpacity: editorManualBackdropOpacity,
			blurPx: editorManualBlurPx,
			surfaceOpacity: editorManualSurfaceOpacity,
			itemOpacity: editorManualItemOpacity
		}
	);
	const radiusVars = getEditorRadiusVars(
		editorCornerRadius,
		editorControlCornerRadius
	);
	const effectiveAudioPaused =
		captureMode === 'file' ? isPaused || audioPaused : audioPaused;

	useEffect(() => {
		if (!open && !maximized) {
			setSelectedOverlayId(null);
		}
	}, [maximized, open, setSelectedOverlayId]);

	function toggleHeaderAudioPause() {
		const nextPaused = !effectiveAudioPaused;
		setAudioPaused(nextPaused);
		if (captureMode === 'file') {
			if (nextPaused) pauseFileForSystem();
			else resumeFileFromSystem();
		}
	}

	function toggleHeaderPauseAll() {
		const shouldResumeAll = effectiveAudioPaused || motionPaused;
		const nextPaused = !shouldResumeAll;
		setAudioPaused(nextPaused);
		setMotionPaused(nextPaused);
		if (captureMode === 'file') {
			if (shouldResumeAll) resumeFileFromSystem();
			else pauseFileForSystem();
		}
	}

	const SIMPLE_HIDDEN_TABS: MainTabId[] = ['motion', 'advanced'];

	const MAIN_TABS: { id: MainTabId; label: string }[] = [
		{ id: 'scene', label: t.tab_scene },
		{ id: 'spectrum', label: t.tab_spectrum },
		{ id: 'looks', label: t.tab_looks },
		{ id: 'layers', label: t.tab_layers },
		{ id: 'motion', label: t.tab_motion },
		{ id: 'audio', label: t.tab_audio },
		{ id: 'advanced', label: t.tab_advanced }
	];

	const visibleTabs =
		uiMode === 'simple'
			? MAIN_TABS.filter(t => !SIMPLE_HIDDEN_TABS.includes(t.id))
			: MAIN_TABS;

	useEffect(() => {
		if (uiMode === 'simple' && SIMPLE_HIDDEN_TABS.includes(tab)) {
			setTab('scene');
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [uiMode]);

	const ADVANCED_TABS: { id: AdvancedSubTab; label: string }[] = [
		{ id: 'track', label: t.tab_track },
		{ id: 'lyrics', label: t.tab_lyrics },
		{ id: 'logo', label: t.tab_logo },
		{ id: 'diagnostics', label: t.tab_diagnostics },
		{ id: 'editor', label: t.tab_editor },
		{ id: 'export', label: t.tab_export },
		{ id: 'perf', label: t.tab_perf }
	];

	function resetSelectedOverlayLayout() {
		const selected = overlays.find(
			overlay => overlay.id === selectedOverlayId
		);
		if (!selected) return;
		updateOverlay(selected.id, {
			enabled: true,
			positionX: 0,
			positionY: 0,
			scale: 1,
			rotation: 0,
			opacity: 1,
			blendMode: 'normal',
			cropShape: 'rectangle',
			edgeFade: 0.08,
			edgeBlur: 0,
			edgeGlow: 0.12
		});
	}

	function resetTab() {
		if (tab === 'scene') {
			resetSceneSlotBindings();
			return;
		}
		if (tab === 'layers') {
			resetSection(
				MAIN_TAB_RESET_KEYS.layers.filter(
					k => !['imageUrl', 'logoUrl'].includes(k as string)
				)
			);
			resetSelectedOverlayLayout();
			return;
		}
		if (tab === 'advanced') {
			resetSection(
				ADVANCED_RESET_KEYS[advancedSub].filter(
					k => !['imageUrl', 'logoUrl'].includes(k as string)
				)
			);
			return;
		}

		resetSection(
			MAIN_TAB_RESET_KEYS[tab].filter(
				k => !['imageUrl', 'logoUrl'].includes(k as string)
			)
		);
	}

	// CSS transform-origin tied to the anchor: scale must always grow into the
	// viewport from the corner that anchors the panel, never "off-screen".
	// Sanity-clamp the scale here too in case persisted state is older / out
	// of range; the slice setter clamps too but a stale value could still arrive.
	const safeUiScale = Math.min(2, Math.max(0.7, editorUiScale ?? 1));
	const panelTransformOrigin = controlPanelAnchor.startsWith('top')
		? controlPanelAnchor.endsWith('left')
			? 'top left'
			: 'top right'
		: controlPanelAnchor.endsWith('left')
			? 'bottom left'
			: 'bottom right';

	// Responsive panel sizing — every dimension below is the **base** (pre-scale)
	// size. Because `transform: scale(N)` enlarges the rendered box without
	// affecting layout, we divide each viewport-bound cap by N so the rendered
	// (post-scale) panel always fits inside the available area:
	//   visualWidth  = baseWidth  * N  ≤  100vw - inset
	//   visualHeight = baseHeight * N  ≤  100dvh - margin
	// Result:
	//   - On a wide display, the cap (30/54rem) limits the BASE width and the
	//     scale grows it horizontally up to N×, which is what the user wants.
	//   - On a narrow display, the (100vw - inset)/N branch wins so the scaled
	//     panel still fits horizontally.
	//   - Vertically the scaled panel always fits inside the dvh minus the
	//     anchor margin, so it can never grow off the top/bottom edge.
	const panelInset =
		'max(0.5rem, env(safe-area-inset-left)) + max(0.5rem, env(safe-area-inset-right))';
	const baseMaxRem = tab === 'scene' ? 54 : 30;
	const panelWidth = `min(${baseMaxRem}rem, calc((100vw - (${panelInset})) / ${safeUiScale}))`;
	const verticalMarginRem = controlPanelAnchor.startsWith('top') ? 8 : 6;
	const panelMaxHeight = `calc((100dvh - ${verticalMarginRem}rem) / ${safeUiScale})`;
	const panelScaleStyle =
		safeUiScale === 1
			? undefined
			: {
					transform: `scale(${safeUiScale})`,
					transformOrigin: panelTransformOrigin
				};

	const TOOL_ITEMS: { id: ActiveTool; icon: React.ReactNode; label: string }[] = [
		{ id: 'none', icon: <MousePointer size={ICON_SIZE.xs} />, label: 'Select' },
		{ id: 'logo', icon: <ImageIcon size={ICON_SIZE.xs} />, label: 'Logo' },
		{ id: 'spectrum', icon: <AudioWaveform size={ICON_SIZE.xs} />, label: 'Spectrum' },
		{ id: 'hud', icon: <SlidersHorizontal size={ICON_SIZE.xs} />, label: 'HUD' }
	];

	return (
		<>
			{(maximized || forceMaximized) && (
				<EditorOverlay
					onClose={() => {
						if (forceMaximized && onForceClose) {
							onForceClose();
							return;
						}
						onMaximizedChange(false);
					}}
				/>
			)}
			{!forceMaximized ? (
				<div
					className={`fixed z-50 ${PANEL_ANCHOR_WRAPPER_CLASS[controlPanelAnchor]}`}
				>
					{/* Launcher button — 44px touch target on mobile, 40px on desktop */}
					<button
						onClick={() => onOpenChange(!open)}
						className={`group h-11 w-11 rounded-full transition-all duration-200 sm:h-10 sm:w-10 ${theme.launcher} ${open ? theme.launcherOpen : ''}`}
						style={{
							borderRadius: 'var(--editor-radius-xl)',
							background: 'var(--editor-button-bg)',
							borderColor: 'var(--editor-button-border)',
							color: 'var(--editor-button-fg)',
							...radiusVars
						}}
						title={open ? 'Close panel' : 'Open editor'}
					>
						<span
							className="relative flex h-full w-full items-center justify-center overflow-hidden"
							style={{ borderRadius: 'var(--editor-radius-xl)' }}
						>
							{logoUrl && !open ? (
								<img
									src={logoUrl}
									alt=""
									className={`h-6 w-6 rounded-full object-cover opacity-85 ring-1 ${theme.launcherImageRing}`}
								/>
							) : open ? (
								<X size={18} />
							) : (
								<Circle size={16} />
							)}
						</span>
					</button>

					{open && (
						<div
							className={`absolute box-border flex min-w-0 flex-col overflow-x-hidden ${theme.panelShell} ${PANEL_ANCHOR_OVERLAY_CLASS[controlPanelAnchor]}`}
							style={{
								maxHeight: panelMaxHeight,
								borderRadius: 'var(--editor-radius-lg)',
								width: panelWidth,
								backgroundColor: 'var(--editor-shell-bg)',
								borderColor: 'var(--editor-shell-border)',
								backdropFilter:
									'blur(var(--editor-shell-blur)) saturate(138%)',
								WebkitBackdropFilter:
									'blur(var(--editor-shell-blur)) saturate(138%)',
								...themeVars,
								...radiusVars,
								...panelScaleStyle
							}}
						>
							{/* ── Header ── */}
							<div
								className={`flex flex-wrap items-center gap-2 px-3 pt-3 pb-2 sm:flex-nowrap sm:gap-1.5 sm:pt-2.5 ${theme.panelHeader}`}
								style={{
									backgroundColor: 'var(--editor-header-bg)',
									borderBottomColor: 'var(--editor-header-border)',
									paddingLeft:
										'max(0.75rem, env(safe-area-inset-left))',
									paddingRight:
										'max(0.75rem, env(safe-area-inset-right))'
								}}
							>
								{/* Title */}
								<span
									className={`text-xs uppercase tracking-widest font-bold mr-auto ${theme.panelTitle}`}
									style={{ color: 'var(--editor-accent-soft)' }}
								>
									{t.title}
								</span>

								{/* Simple / Advanced pill */}
								<div
									className="flex items-center rounded-full border overflow-hidden text-[10px]"
									style={{
										borderColor: 'var(--editor-accent-border)',
										background: 'var(--editor-tag-bg)'
									}}
								>
									<button
										onClick={() => setUIMode('simple')}
										className="px-2.5 py-0.5 transition-colors"
										style={
											uiMode === 'simple'
												? {
														background: 'var(--editor-active-bg)',
														color: 'var(--editor-active-fg)'
												  }
												: { color: 'var(--editor-accent-muted)' }
										}
									>
										Simple
									</button>
									<button
										onClick={() => setUIMode('advanced')}
										className="px-2.5 py-0.5 transition-colors"
										style={
											uiMode === 'advanced'
												? {
														background: 'var(--editor-active-bg)',
														color: 'var(--editor-active-fg)'
												  }
												: { color: 'var(--editor-accent-muted)' }
										}
									>
										Advanced
									</button>
								</div>

								{/* Drag mode toggle */}
								<IconButton
									active={enableDragMode}
									onClick={() => setEnableDragMode(!enableDragMode)}
									title={enableDragMode ? 'Drag mode on — click to disable' : 'Enable drag mode'}
								>
									<Move size={ICON_SIZE.sm} />
								</IconButton>

								{/* Audio play/pause */}
								<IconButton
									onClick={toggleHeaderAudioPause}
									title={t.hint_pause_audio_only}
								>
									{effectiveAudioPaused ? <Play size={ICON_SIZE.sm} /> : <Pause size={ICON_SIZE.sm} />}
								</IconButton>

								{/* Pause all — advanced mode only */}
								{uiMode === 'advanced' && (
									<IconButton
										variant="warning"
										onClick={toggleHeaderPauseAll}
										title={t.hint_pause_all}
									>
										{effectiveAudioPaused || motionPaused ? (
											<Play size={ICON_SIZE.sm} />
										) : (
											<Pause size={ICON_SIZE.sm} />
										)}
									</IconButton>
								)}

								{/* Fullscreen */}
								{fullscreenSupported ? (
									<IconButton
										onClick={() => void toggleFullscreen()}
										title={isFullscreen ? t.label_exit_fullscreen : t.label_enter_fullscreen}
									>
										{isFullscreen ? <Minimize2 size={ICON_SIZE.sm} /> : <Maximize2 size={ICON_SIZE.sm} />}
									</IconButton>
								) : null}

								{/* Language — advanced mode only */}
								{uiMode === 'advanced' && (
									<button
										onClick={() =>
											setLanguage(language === 'en' ? 'es' : 'en')
										}
										className="text-[10px] px-1.5 py-0.5 rounded border transition-colors"
										style={{
											borderRadius: 'var(--editor-radius-md)',
											background: 'var(--editor-button-bg)',
											borderColor: 'var(--editor-button-border)',
											color: 'var(--editor-button-fg)'
										}}
										title="Toggle language"
									>
										{language === 'en' ? 'ES' : 'EN'}
									</button>
								)}

								{/* Maximize workspace */}
								<IconButton
									onClick={() => onMaximizedChange(true)}
									title={t.label_open_editor_workspace}
								>
									<LayoutGrid size={ICON_SIZE.sm} />
								</IconButton>
							</div>

							{/* ── Active Tool Bar (only in drag mode) ── */}
							{enableDragMode && (
								<div
									className="flex items-center gap-1 px-3 py-1.5"
									style={{
										background: 'var(--editor-header-bg)',
										borderBottom: '1px solid var(--editor-tabbar-border)'
									}}
								>
									<Zap size={10} style={{ color: 'var(--editor-accent-muted)' }} />
									<span
										className="text-[10px] mr-2"
										style={{ color: 'var(--editor-accent-muted)' }}
									>
										Active tool
									</span>
									{TOOL_ITEMS.map(tool => (
										<button
											key={tool.id}
											onClick={() => setActiveTool(tool.id)}
											className="flex items-center gap-1 rounded border px-2 py-0.5 text-[10px] transition-colors"
											style={
												activeTool === tool.id
													? {
															borderRadius: 'var(--editor-radius-sm)',
															background: 'var(--editor-active-bg)',
															borderColor: 'var(--editor-accent-color)',
															color: 'var(--editor-active-fg)',
															boxShadow: '0 0 6px var(--editor-accent-color)'
													  }
													: {
															borderRadius: 'var(--editor-radius-sm)',
															background: 'var(--editor-tag-bg)',
															borderColor: 'var(--editor-tag-border)',
															color: 'var(--editor-tag-fg)'
													  }
											}
										>
											{tool.icon}
											{tool.label}
										</button>
									))}
								</div>
							)}

							{/* ── Main Tabs ── */}
							<div
								className={`flex min-w-0 flex-wrap gap-1 p-1.5 ${theme.tabBar}`}
								style={{
									background: 'var(--editor-tabbar-bg)',
									borderBottomColor: 'var(--editor-tabbar-border)'
								}}
							>
								{visibleTabs.map(row => (
									<button
										key={row.id}
										onClick={() => setTab(row.id)}
										className="rounded border px-3 py-2 text-sm whitespace-nowrap transition-colors sm:px-2 sm:py-1 sm:text-xs"
										style={
											tab === row.id
												? {
														borderRadius: 'var(--editor-radius-sm)',
														background: 'var(--editor-active-bg)',
														borderColor: 'var(--editor-accent-border)',
														color: 'var(--editor-active-fg)'
												  }
												: {
														borderRadius: 'var(--editor-radius-sm)',
														background: 'var(--editor-tag-bg)',
														borderColor: 'var(--editor-tag-border)',
														color: 'var(--editor-tag-fg)'
												  }
										}
									>
										{row.label}
									</button>
								))}
							</div>

							{/* ── Tab Content ── */}
							<div className="editor-scroll flex flex-1 min-h-0 min-w-0 flex-col gap-2.5 overflow-x-hidden overflow-y-auto px-3 pt-4 pb-6">
								<VisualWorkloadBanner />
								{tab === 'advanced' ? (
									<div
										className="flex flex-wrap gap-1"
										style={{
											borderBottom:
												'1px solid var(--editor-tabbar-border)',
											paddingBottom: 6
										}}
									>
										{ADVANCED_TABS.map(row => (
											<button
												key={row.id}
												type="button"
												onClick={() => setAdvancedSub(row.id)}
												className="rounded border px-2 py-0.5 text-[10px] whitespace-nowrap transition-colors"
												style={
													advancedSub === row.id
														? {
																background:
																	'var(--editor-active-bg)',
																borderColor:
																	'var(--editor-accent-border)',
																color:
																	'var(--editor-active-fg)'
															}
														: {
																background:
																	'var(--editor-tag-bg)',
																borderColor:
																	'var(--editor-tag-border)',
																color:
																	'var(--editor-tag-fg)'
															}
												}
											>
												{row.label}
											</button>
										))}
									</div>
								) : null}
								<ControlTabSuspense>
									{tab === 'scene' && (
										<SceneTab
											onReset={resetTab}
											onRequestMainTab={setTab}
										/>
									)}
									{tab === 'spectrum' && (
										<SpectrumTab onReset={resetTab} />
									)}
									{tab === 'looks' && (
										<FiltersTab onReset={resetTab} />
									)}
									{tab === 'layers' && (
										<>
											<BgTab onReset={resetTab} />
											<LayersTab onReset={resetTab} />
											<OverlaysTab onReset={resetTab} />
										</>
									)}
									{tab === 'motion' && (
										<MotionTab
											onResetParticles={() =>
												resetSection(
													(LEGACY_TAB_KEYS.particles ?? []).filter(
														k =>
															!['imageUrl', 'logoUrl'].includes(
																k as string
															)
													)
												)
											}
											onResetRain={() =>
												resetSection(
													(LEGACY_TAB_KEYS.rain ?? []).filter(
														k =>
															!['imageUrl', 'logoUrl'].includes(
																k as string
															)
													)
												)
											}
										/>
									)}
									{tab === 'audio' && (
										<AudioTab onReset={resetTab} />
									)}
									{tab === 'advanced' && advancedSub === 'track' && (
										<TrackTitleTab onReset={resetTab} />
									)}
									{tab === 'advanced' &&
										advancedSub === 'lyrics' && (
											<LyricsTab onReset={resetTab} />
										)}
									{tab === 'advanced' && advancedSub === 'logo' && (
										<LogoTab onReset={resetTab} />
									)}
									{tab === 'advanced' &&
										advancedSub === 'diagnostics' && (
											<DiagnosticsTab onReset={resetTab} />
										)}
									{tab === 'advanced' && advancedSub === 'editor' && (
										<EditorTab onReset={resetTab} />
									)}
									{tab === 'advanced' && advancedSub === 'export' && (
										<ExportTab />
									)}
									{tab === 'advanced' && advancedSub === 'perf' && (
										<PerfTab />
									)}
								</ControlTabSuspense>
							</div>
						</div>
					)}
				</div>
			) : null}
		</>
	);
}
